package com.djs.answerlens;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

/**
 * "Ask AnswerLens" in the text-selection menu. Opens no window: it hands the selected text to the
 * running service, which shows the answer in the floating card, then closes at once.
 */
public class ProcessTextActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        CharSequence cs = getIntent() == null ? null : getIntent().getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT);
        String sel = cs == null ? "" : cs.toString().trim();
        LensService svc = LensService.instance;
        if (sel.isEmpty()) {
            Toast.makeText(this, "No text was selected", Toast.LENGTH_SHORT).show();
        } else if (svc == null) {
            Toast.makeText(this, "Turn on AnswerLens in Accessibility settings first", Toast.LENGTH_LONG).show();
        } else {
            BankRepo.load(this);
            svc.answerSelection(sel);
        }
        finish();
        overridePendingTransition(0, 0);
    }
}
