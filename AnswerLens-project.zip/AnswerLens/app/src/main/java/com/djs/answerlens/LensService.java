package com.djs.answerlens;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.SharedPreferences;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Reads on-screen text, matches questions against the bank, and shows the answer as floating text
 *  (and/or boxes on screen; optionally taps it). Nothing else is opened. */
public class LensService extends AccessibilityService {
    static volatile LensService instance;

    private static final int GREEN = 0xFF1E9E4A, ORANGE = 0xFFE67E00, GREY = 0xFF666666, BLUE = 0xFF2962FF;
    private static final int MAX_NODES = 2500, LOOKAHEAD = 25;

    private static final class Item {
        final String text;
        final Rect b;
        final AccessibilityNodeInfo node;

        Item(String t, Rect b, AccessibilityNodeInfo n) { this.text = t; this.b = b; this.node = n; }
    }

    private final Handler h = new Handler(Looper.getMainLooper());
    private final Bank aiBank = new Bank();
    private final Set<String> tapped = new HashSet<>();
    private List<String> lastLines = new ArrayList<>();
    private WindowManager wm;
    private HighlightView hl;
    private LinearLayout bubble;
    private TextView btnToggle, btnAi;
    private WindowManager.LayoutParams bubbleLp;
    // Floating answer card
    private LinearLayout card;
    private TextView cardText;
    private WindowManager.LayoutParams cardLp;
    private boolean compact;
    // Pinned content stays in the card until you tap it: AI results, selected-text answers, or a status message.
    private List<String[]> pinRows = new ArrayList<>();   // {question, answer, ai "1"/"0"}
    private String pinMsg, pinSel;
    private List<String[]> lastRows = new ArrayList<>();
    private final Set<String> asked = new HashSet<>();
    private boolean active = true, pending, aiBusy;
    private long lastAi;
    private int nodeCount;

    private final Runnable scanR = new Runnable() {
        @Override public void run() { pending = false; scan(); }
    };

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        BankRepo.load(this);
        addOverlay();
        addCard();
        addBubble();
        schedule();
    }

    @Override
    public void onDestroy() {
        instance = null;
        h.removeCallbacksAndMessages(null);
        try { if (hl != null) wm.removeView(hl); } catch (Exception ignored) { }
        try { if (bubble != null) wm.removeView(bubble); } catch (Exception ignored) { }
        try { if (card != null) wm.removeView(card); } catch (Exception ignored) { }
        super.onDestroy();
    }

    @Override
    public void onInterrupt() { }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
        if (!active || e == null) return;
        CharSequence pkg = e.getPackageName();
        if (pkg != null && getPackageName().contentEquals(pkg)) return;
        if (e.getEventType() == AccessibilityEvent.TYPE_VIEW_SCROLLED) hl.clear();
        schedule();
    }

    private void schedule() {
        if (pending) return;
        pending = true;
        h.postDelayed(scanR, 200);
    }

    // ---------- scanning ----------

    private void scan() {
        if (!active || hl == null) return;
        AccessibilityNodeInfo root;
        try { root = getRootInActiveWindow(); } catch (Exception ex) { root = null; }
        if (root == null) { hl.clear(); return; }
        CharSequence pkg = root.getPackageName();
        if (pkg != null && getPackageName().contentEquals(pkg)) { hl.clear(); showRows(new ArrayList<String[]>()); return; }

        List<Item> items = new ArrayList<>();
        nodeCount = 0;
        try { collect(root, items, 0); } catch (Exception ignored) { }

        List<String> lines = new ArrayList<>();
        String prev = null;
        for (Item it : items) {
            if (!it.text.equals(prev)) lines.add(it.text);
            prev = it.text;
        }
        lastLines = lines;

        int n = items.size();
        Bank.Entry[] match = new Bank.Entry[n];
        for (int i = 0; i < n; i++) {
            Bank.Entry e = BankRepo.bank.find(items.get(i).text);
            if (e == null) e = aiBank.find(items.get(i).text);
            match[i] = e;
        }

        SharedPreferences p = Cfg.get(this);
        boolean autoTap = p.getBoolean(Cfg.AUTO_TAP, false), aiTap = p.getBoolean(Cfg.AI_TAP, false);
        String style = p.getString(Cfg.STYLE, Cfg.STYLE_FLOAT);
        boolean boxes = !Cfg.STYLE_FLOAT.equals(style), floating = !Cfg.STYLE_BOX.equals(style);
        List<HighlightView.Mark> marks = new ArrayList<>();
        List<String[]> rows = new ArrayList<>();
        Bank.Entry lastQ = null;
        int lastQi = -10;
        for (int i = 0; i < n; i++) {
            Bank.Entry e = match[i];
            if (e == null) continue;
            if (e == lastQ && i - lastQi <= 3) { lastQi = i; continue; } // same question exposed twice
            lastQ = e;
            lastQi = i;

            Item best = null;
            double bs = 0.8;
            for (int j = i + 1; j < n && j <= i + LOOKAHEAD; j++) {
                if (match[j] != null && match[j] != e) break; // reached the next question
                if (match[j] == e) continue;
                double s = Matcher.answerScore(e.answer, items.get(j).text);
                if (s > bs) { bs = s; best = items.get(j); if (s >= 1.0) break; }
            }
            int color = e.ai ? ORANGE : GREEN;
            rows.add(new String[]{items.get(i).text, e.answer, e.ai ? "1" : "0", best == null ? "0" : "1"});
            if (best != null) {
                marks.add(new HighlightView.Mark(best.b, color, e.ai ? "AI" : "✓", true));
                if (autoTap && (!e.ai || aiTap) && tapped.add(e.nq)) tap(best);
            } else {
                marks.add(new HighlightView.Mark(items.get(i).b, color,
                        (e.ai ? "AI: " : "Answer: ") + e.answer, false));
            }
        }
        if (boxes) hl.setMarks(marks); else hl.clear();
        showRows(floating ? rows : new ArrayList<String[]>());

        // Optional: send new question-like lines to the AI without pressing the button.
        if (p.getBoolean(Cfg.AUTO_AI, false) && !aiBusy && System.currentTimeMillis() - lastAi > 4000) {
            List<String> fresh = new ArrayList<>();
            for (int i = 0; i < n; i++) {
                if (match[i] != null || !Matcher.looksLikeQuestion(items.get(i).text)) continue;
                String k = Matcher.norm(items.get(i).text);
                if (!asked.contains(k)) fresh.add(k);
            }
            if (!fresh.isEmpty()) {
                if (asked.size() > 2000) asked.clear();
                asked.addAll(fresh);
                askAi(true);
            }
        }
    }

    private void collect(AccessibilityNodeInfo node, List<Item> out, int depth) {
        if (node == null || depth > 70 || nodeCount++ > MAX_NODES) return;
        if (!node.isVisibleToUser() || node.isPassword()) return;
        CharSequence cs = node.getText();
        if (cs == null || cs.length() == 0) cs = node.getContentDescription();
        if (cs != null) {
            String t = cs.toString().trim();
            if (!t.isEmpty() && t.length() <= 600) {
                Rect b = new Rect();
                node.getBoundsInScreen(b);
                if (b.width() > 0 && b.height() > 0) out.add(new Item(t, b, node));
            }
        }
        int cc = node.getChildCount();
        for (int i = 0; i < cc; i++) collect(node.getChild(i), out, depth + 1);
    }

    private void tap(Item it) {
        try {
            AccessibilityNodeInfo nd = it.node;
            for (int k = 0; k < 4 && nd != null; k++) {
                if (nd.isClickable()) {
                    Rect r = new Rect();
                    nd.getBoundsInScreen(r);
                    // Only click a parent that is clearly this choice's own row, not the whole question card.
                    if (r.height() <= it.b.height() * 4 + 40
                            && nd.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return;
                    break;
                }
                nd = nd.getParent();
            }
            Path path = new Path();
            path.moveTo(it.b.centerX(), it.b.centerY());
            GestureDescription g = new GestureDescription.Builder()
                    .addStroke(new GestureDescription.StrokeDescription(path, 0, 60)).build();
            dispatchGesture(g, null, null);
        } catch (Exception ignored) { }
    }

    // ---------- AI fallback ----------

    private void askAi(final boolean quiet) {
        if (aiBusy) return;
        SharedPreferences p = Cfg.get(this);
        final String type = p.getString(Cfg.AI_TYPE, Cfg.TYPE_ANTHROPIC);
        final String url = p.getString(Cfg.AI_URL, Cfg.URL_ANTHROPIC).trim();
        final String model = p.getString(Cfg.AI_MODEL, Cfg.MODEL_ANTHROPIC).trim();
        final String key = p.getString(Cfg.AI_KEY, "").trim();
        final boolean web = p.getBoolean(Cfg.WEB, true);
        if (key.isEmpty() || url.isEmpty() || model.isEmpty()) {
            if (!quiet) status("No API key yet. Open AnswerLens → step 5 → paste your key → Save AI settings.");
            return;
        }
        if (!active) { status("Scanning is OFF. Tap the ON/OFF bubble first."); return; }
        final List<String> lines = new ArrayList<>(lastLines);
        if (lines.isEmpty()) {
            if (!quiet) status("No readable text on this screen (pictures and some apps can't be read).");
            return;
        }
        aiBusy = true;
        lastAi = System.currentTimeMillis();
        btnAi.setText("…");
        if (!quiet) status("Searching for answers…");
        new Thread(new Runnable() {
            @Override public void run() {
                List<String[]> res = null;
                String err = null;
                try { res = AiClient.askScreen(type, url, model, key, web, lines); }
                catch (Exception ex) { err = ex.getMessage() == null ? ex.toString() : ex.getMessage(); }
                final List<String[]> fres = res;
                final String ferr = err;
                h.post(new Runnable() {
                    @Override public void run() {
                        aiBusy = false;
                        lastAi = System.currentTimeMillis();
                        if (btnAi != null) btnAi.setText("AI");
                        if (ferr != null) { if (quiet) renderCard(); else status("AI failed: " + ferr); return; }
                        int added = 0;
                        for (String[] qa : fres) {
                            if (BankRepo.bank.find(qa[0]) != null) continue; // your bank wins
                            if (aiBank.add(qa[0], qa[1], true)) added++;
                        }
                        if (!quiet) {
                            List<String[]> rows = new ArrayList<>();
                            for (String[] qa : fres) {
                                Bank.Entry be = BankRepo.bank.find(qa[0]);
                                rows.add(be != null ? new String[]{qa[0], be.answer, "0"} : new String[]{qa[0], qa[1], "1"});
                            }
                            if (rows.isEmpty()) status("AI found no questions on this screen.");
                            else { pinMsg = null; pinSel = null; pinRows = rows; renderCard(); }
                        } else renderCard();
                        schedule();
                    }
                });
            }
        }).start();
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }


    // ---------- floating answer card ----------

    private void addCard() {
        float dp = getResources().getDisplayMetrics().density;
        int sw = getResources().getDisplayMetrics().widthPixels, sh = getResources().getDisplayMetrics().heightPixels;
        card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xEE1F2124);
        bg.setCornerRadius(14 * dp);
        bg.setStroke((int) (1 * dp), 0x55FFFFFF);
        card.setBackground(bg);
        int pd = (int) (12 * dp);
        card.setPadding(pd, (int) (9 * dp), pd, (int) (10 * dp));
        cardText = new TextView(this);
        cardText.setTextColor(0xFFFFFFFF);
        cardText.setTextSize(15);
        cardText.setMaxWidth(sw - (int) (40 * dp));
        cardText.setLineSpacing(2 * dp, 1f);
        card.addView(cardText);

        cardLp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        cardLp.gravity = Gravity.TOP | Gravity.START;
        cardLp.x = (int) (12 * dp);
        cardLp.y = Math.max((int) (80 * dp), sh - (int) (300 * dp));

        card.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (pinMsg != null || !pinRows.isEmpty()) {          // tap dismisses pinned content
                    pinMsg = null; pinSel = null; pinRows = new ArrayList<>();
                } else compact = !compact;                          // otherwise: answer only <-> question + answer
                renderCard();
            }
        });
        card.setOnTouchListener(new Drag(ViewConfiguration.get(this).getScaledTouchSlop(), card, cardLp));
        card.setVisibility(View.GONE);
        wm.addView(card, cardLp);
    }

    private void showRows(List<String[]> rows) {
        if (sameRows(rows, lastRows)) return;
        lastRows = rows;
        renderCard();
    }

    private static boolean sameRows(List<String[]> a, List<String[]> b) {
        if (a.size() != b.size()) return false;
        for (int i = 0; i < a.size(); i++) {
            String[] x = a.get(i), y = b.get(i);
            for (int k = 0; k < x.length; k++) if (!x[k].equals(y[k])) return false;
        }
        return true;
    }

    /** Called from ProcessTextActivity: answer the selected text in the floating card. */
    void answerSelection(final String sel) {
        Bank.Entry e = BankRepo.bank.find(sel);
        if (e == null) e = aiBank.find(sel);
        if (e != null) { pin(sel, e.answer, e.ai); return; }
        SharedPreferences p = Cfg.get(this);
        final String type = p.getString(Cfg.AI_TYPE, Cfg.TYPE_ANTHROPIC);
        final String url = p.getString(Cfg.AI_URL, Cfg.URL_ANTHROPIC).trim();
        final String model = p.getString(Cfg.AI_MODEL, Cfg.MODEL_ANTHROPIC).trim();
        final String key = p.getString(Cfg.AI_KEY, "").trim();
        final boolean web = p.getBoolean(Cfg.WEB, true);
        if (key.isEmpty() || url.isEmpty() || model.isEmpty()) {
            pin(sel, "Not in your bank. Add an AI key in the AnswerLens app.", true);
            return;
        }
        pin(sel, web ? "Searching the web…" : "Thinking…", true);
        new Thread(new Runnable() {
            @Override public void run() {
                String out;
                try { out = AiClient.askOne(type, url, model, key, web, sel); }
                catch (Exception ex) { out = "Could not get an answer. " + ex.getMessage(); }
                final String fout = out;
                h.post(new Runnable() {
                    @Override public void run() { if (sel.equals(pinSel)) pin(sel, fout, true); }
                });
            }
        }).start();
    }

    private void pin(String q, String a, boolean ai) {
        pinMsg = null;
        pinSel = q;
        pinRows = new ArrayList<>();
        pinRows.add(new String[]{q, a, ai ? "1" : "0"});
        renderCard();
    }

    /** Shows a status/error message in the floating card until it is tapped away. */
    private void status(String msg) {
        pinMsg = msg;
        pinSel = null;
        pinRows = new ArrayList<>();
        renderCard();
    }

    private void renderCard() {
        if (card == null) return;
        float dp = getResources().getDisplayMetrics().density;
        SpannableStringBuilder sb = new SpannableStringBuilder();
        if (pinMsg != null) {
            addLine(sb, pinMsg, 0xFFFFFFFF, 14, false, dp);
        } else if (!pinRows.isEmpty()) {
            int shown = 0;
            for (String[] r : pinRows) {
                if (shown++ >= 6) break;
                addRow(sb, r[0], r[1], "1".equals(r[2]), dp);
            }
        } else {
            int shown = 0;
            for (String[] r : lastRows) {
                if (shown++ >= 4) break;
                addRow(sb, r[0], r[1], "1".equals(r[2]), dp);
            }
            if (aiBusy && shown == 0) addLine(sb, "Searching for answers…", 0xFFBDBDBD, 13, false, dp);
        }
        if (sb.length() == 0) { card.setVisibility(View.GONE); return; }
        cardText.setText(sb);
        card.setVisibility(View.VISIBLE);
    }

    private void addRow(SpannableStringBuilder sb, String q, String a, boolean ai, float dp) {
        if (sb.length() > 0) sb.append("\n\n");
        if (!compact && q != null) {
            String qs = q.replaceAll("\\s*\\*\\s*$", "").replace('\n', ' ').trim();
            if (qs.length() > 90) qs = qs.substring(0, 89) + "…";
            addLine(sb, qs, 0xFFBDBDBD, 12, false, dp);
            sb.append("\n");
        }
        addLine(sb, (ai ? "AI ➜ " : "✓ ") + a, ai ? 0xFFFFB74D : 0xFF7CE38B, 16, true, dp);
    }

    private static void addLine(SpannableStringBuilder sb, String s, int color, int sp, boolean bold, float dp) {
        int st = sb.length();
        sb.append(s);
        int en = sb.length();
        sb.setSpan(new ForegroundColorSpan(color), st, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        sb.setSpan(new AbsoluteSizeSpan(sp, true), st, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        if (bold) sb.setSpan(new StyleSpan(Typeface.BOLD), st, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    }

    // ---------- overlay windows ----------

    private void addOverlay() {
        hl = new HighlightView(this);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
        wm.addView(hl, lp);
    }

    private void addBubble() {
        float dp = getResources().getDisplayMetrics().density;
        bubble = new LinearLayout(this);
        bubble.setOrientation(LinearLayout.VERTICAL);
        btnToggle = pill("ON", GREEN, dp);
        btnAi = pill("AI", BLUE, dp);
        bubble.addView(btnToggle);
        LinearLayout.LayoutParams gap = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        gap.topMargin = (int) (6 * dp);
        bubble.addView(btnAi, gap);

        bubbleLp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        bubbleLp.gravity = Gravity.TOP | Gravity.START;
        bubbleLp.x = getResources().getDisplayMetrics().widthPixels - (int) (60 * dp);
        bubbleLp.y = (int) (220 * dp);

        btnToggle.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { toggle(); }
        });
        btnAi.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { askAi(false); }
        });
        View.OnTouchListener drag = new Drag(ViewConfiguration.get(this).getScaledTouchSlop(), bubble, bubbleLp);
        btnToggle.setOnTouchListener(drag);
        btnAi.setOnTouchListener(drag);
        wm.addView(bubble, bubbleLp);
    }

    private TextView pill(String label, int color, float dp) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(13);
        t.setGravity(Gravity.CENTER);
        t.setMinWidth((int) (46 * dp));
        t.setMinHeight((int) (46 * dp));
        t.setBackground(round(color, dp));
        return t;
    }

    private static GradientDrawable round(int color, float dp) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        g.setStroke((int) (2 * dp), 0xFFFFFFFF);
        return g;
    }

    private void toggle() {
        active = !active;
        float dp = getResources().getDisplayMetrics().density;
        btnToggle.setText(active ? "ON" : "OFF");
        btnToggle.setBackground(round(active ? GREEN : GREY, dp));
        if (active) schedule(); else { hl.clear(); showRows(new ArrayList<String[]>()); }
    }

    /** Lets an overlay window be dragged; a touch that does not move counts as a click. */
    private final class Drag implements View.OnTouchListener {
        private final int slop;
        private final View win;
        private final WindowManager.LayoutParams lp;
        private float downX, downY;
        private int startX, startY;
        private boolean moved;

        Drag(int slop, View win, WindowManager.LayoutParams lp) { this.slop = slop; this.win = win; this.lp = lp; }

        @Override
        public boolean onTouch(View v, MotionEvent ev) {
            switch (ev.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = ev.getRawX(); downY = ev.getRawY();
                    startX = lp.x; startY = lp.y;
                    moved = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float dx = ev.getRawX() - downX, dy = ev.getRawY() - downY;
                    if (!moved && Math.abs(dx) < slop && Math.abs(dy) < slop) return true;
                    moved = true;
                    lp.x = Math.max(0, startX + (int) dx);
                    lp.y = Math.max(0, startY + (int) dy);
                    try { wm.updateViewLayout(win, lp); } catch (Exception ignored) { }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!moved) v.performClick();
                    return true;
                default:
                    return true;
            }
        }
    }
}
