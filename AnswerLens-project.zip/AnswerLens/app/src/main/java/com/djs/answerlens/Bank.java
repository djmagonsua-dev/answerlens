package com.djs.answerlens;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** In-memory question -> answer bank with fuzzy lookup (no Android dependencies). */
public final class Bank {
    public static final class Entry {
        public final String question, answer, nq;
        public final boolean ai;
        final Set<String> tq;

        Entry(String q, String a, boolean ai) {
            this.question = q;
            this.answer = a;
            this.ai = ai;
            this.nq = Matcher.norm(q);
            this.tq = Matcher.tokens(nq);
        }
    }

    private static final double THRESHOLD = 0.82;
    private static final Entry NONE = new Entry("", "", false);
    private final List<Entry> list = new ArrayList<>();
    private final Map<String, Entry> exact = new HashMap<>();
    private final Map<String, Entry> cache = new HashMap<>();

    public int size() { return list.size(); }

    public void clear() { list.clear(); exact.clear(); cache.clear(); }

    public boolean add(String q, String a, boolean ai) {
        if (q == null || a == null || a.trim().isEmpty()) return false;
        Entry e = new Entry(q.trim(), a.trim(), ai);
        if (e.nq.length() < 4) return false;
        Entry old = exact.put(e.nq, e);
        if (old != null) list.remove(old);
        list.add(e);
        cache.clear();
        return true;
    }

    /** Returns the bank entry whose question matches this on-screen text, or null. */
    public Entry find(String screenText) {
        if (list.isEmpty() || screenText == null) return null;
        Entry c = cache.get(screenText);
        if (c != null) return c == NONE ? null : c;
        String n = Matcher.norm(screenText);
        Entry best = null;
        if (n.length() >= 6) {
            best = exact.get(n);
            if (best == null) {
                Set<String> t = Matcher.tokens(n);
                if (t.size() >= 2) {
                    double bs = THRESHOLD;
                    for (Entry e : list) {
                        double s = Matcher.score(n, t, e.nq, e.tq);
                        if (s >= bs) { bs = s; best = e; }
                    }
                }
            }
        }
        if (cache.size() > 3000) cache.clear();
        cache.put(screenText, best == null ? NONE : best);
        return best;
    }
}
