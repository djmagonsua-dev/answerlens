package com.djs.answerlens;

import java.util.ArrayList;
import java.util.List;

/** Minimal CSV/TSV reader: quoted fields, embedded commas and newlines (no Android dependencies). */
public final class CsvParser {
    private CsvParser() {}

    public static List<String[]> rows(String text) {
        if (text.startsWith("﻿")) text = text.substring(1);
        int nl = text.indexOf('\n');
        String first = nl < 0 ? text : text.substring(0, nl);
        char d = ',';
        if (first.indexOf('\t') >= 0) d = '\t';
        else if (first.indexOf(',') < 0 && first.indexOf(';') >= 0) d = ';';

        List<String[]> out = new ArrayList<>();
        List<String> row = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        boolean q = false;
        for (int i = 0; i < text.length(); i++) {
            char ch = text.charAt(i);
            if (q) {
                if (ch == '"') {
                    if (i + 1 < text.length() && text.charAt(i + 1) == '"') { cur.append('"'); i++; }
                    else q = false;
                } else cur.append(ch);
            } else if (ch == '"' && cur.length() == 0) {
                q = true;
            } else if (ch == d) {
                row.add(cur.toString()); cur.setLength(0);
            } else if (ch == '\n' || ch == '\r') {
                if (ch == '\r' && i + 1 < text.length() && text.charAt(i + 1) == '\n') i++;
                row.add(cur.toString()); cur.setLength(0);
                flush(out, row);
            } else cur.append(ch);
        }
        row.add(cur.toString());
        flush(out, row);
        return out;
    }

    private static void flush(List<String[]> out, List<String> row) {
        boolean any = false;
        for (String s : row) if (!s.trim().isEmpty()) { any = true; break; }
        if (any) out.add(row.toArray(new String[0]));
        row.clear();
    }

    /** Converts rows to {question, answer} pairs. Uses header names when present, else columns 1 and 2. */
    public static List<String[]> pairs(String text) {
        List<String[]> rows = rows(text);
        List<String[]> out = new ArrayList<>();
        if (rows.isEmpty()) return out;
        int qi = 0, ai = 1, start = 0;
        String[] h = rows.get(0);
        int hq = -1, ha = -1;
        for (int i = 0; i < h.length; i++) {
            String n = h[i].trim().toLowerCase();
            if (hq < 0 && n.startsWith("question")) hq = i;
            if (ha < 0 && (n.equals("answer") || n.startsWith("correct") || n.equals("ans") || n.equals("key"))) ha = i;
        }
        if (hq >= 0 && ha >= 0) { qi = hq; ai = ha; start = 1; }
        for (int r = start; r < rows.size(); r++) {
            String[] c = rows.get(r);
            if (c.length > Math.max(qi, ai) && !c[qi].trim().isEmpty() && !c[ai].trim().isEmpty())
                out.add(new String[]{c[qi].trim(), c[ai].trim()});
        }
        return out;
    }
}
