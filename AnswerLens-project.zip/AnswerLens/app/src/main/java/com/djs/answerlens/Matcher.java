package com.djs.answerlens;

import java.text.Normalizer;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/** Pure text-matching helpers (no Android dependencies). */
public final class Matcher {
    private Matcher() {}

    /** Removes list prefixes such as "1. ", "a) ", "(B) ", "12: ". */
    public static String stripPrefix(String s) {
        return s.replaceFirst("^\\s*\\(?([A-Za-z]|\\d{1,3})[\\.\\)\\:]\\s+", "");
    }

    public static String norm(String s) {
        if (s == null) return "";
        s = stripPrefix(s);
        s = Normalizer.normalize(s, Normalizer.Form.NFKD).replaceAll("\\p{M}+", "");
        return s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", " ").trim();
    }

    public static Set<String> tokens(String norm) {
        Set<String> t = new HashSet<>();
        if (norm.isEmpty()) return t;
        for (String w : norm.split(" ")) if (!w.isEmpty()) t.add(w);
        return t;
    }

    public static double dice(Set<String> a, Set<String> b) {
        if (a.isEmpty() || b.isEmpty()) return 0;
        Set<String> small = a.size() <= b.size() ? a : b;
        Set<String> big = small == a ? b : a;
        int common = 0;
        for (String w : small) if (big.contains(w)) common++;
        return 2.0 * common / (a.size() + b.size());
    }

    /** Similarity of two normalized strings, 0..1. */
    public static double score(String na, Set<String> ta, String nb, Set<String> tb) {
        if (na.equals(nb)) return 1.0;
        int la = na.length(), lb = nb.length();
        int min = Math.min(la, lb), max = Math.max(la, lb);
        if (min >= 15 && min >= 0.6 * max && (na.contains(nb) || nb.contains(na))) return 0.92;
        double all = dice(ta, tb);
        if (all < 0.75) return all;
        // Common words inflate the score ("what is the ... of ..."); the key words must agree too.
        Set<String> ca = content(ta), cb = content(tb);
        if (ca.isEmpty() || cb.isEmpty()) return all;
        return Math.min(all, dice(ca, cb));
    }

    private static final Set<String> STOP = new HashSet<>(java.util.Arrays.asList(
            "a", "an", "the", "is", "are", "was", "were", "be", "of", "in", "on", "at", "to", "for", "by", "and",
            "or", "what", "which", "who", "whom", "when", "where", "how", "why", "that", "this", "these", "those",
            "it", "its", "as", "with", "from", "s", "do", "does", "did", "shall", "will", "can", "may", "following",
            "ang", "ng", "sa", "mga", "ay", "na", "si", "ano", "sino", "alin"));

    private static Set<String> content(Set<String> t) {
        Set<String> c = new HashSet<>();
        for (String w : t) if (!STOP.contains(w)) c.add(w);
        return c;
    }

    /** True when an on-screen line reads like a question or a fill-in-the-blank item. */
    public static boolean looksLikeQuestion(String raw) {
        if (raw == null) return false;
        String s = stripPrefix(raw).trim().replaceAll("[\\s\\*]+$", "");
        if (s.length() < 12 || s.length() > 400) return false;
        if (s.split("\\s+").length < 3) return false;
        if (s.endsWith("?") || s.contains("___")) return true;
        if (s.endsWith(":") && s.split("\\s+").length >= 5) return true;
        return s.toLowerCase(Locale.ROOT).matches(
                "^(what|which|who|whom|whose|when|where|why|how|identify|define|choose|select)\\b.{10,}[:\\.]?$");
    }

    /** How well an on-screen text matches the stored correct answer, 0..1. */
    public static double answerScore(String bankAnswerRaw, String screenRaw) {
        String a = bankAnswerRaw.trim();
        if (a.matches("[A-Ea-e]")) {
            // Answer key given as a letter: match a choice labelled "B." / "b)" / "(B)"
            return screenRaw.matches("(?s)^\\s*\\(?[" + a.toLowerCase(Locale.ROOT) + a.toUpperCase(Locale.ROOT)
                    + "][\\.\\)\\:].*") ? 1.0 : 0.0;
        }
        String na = norm(a), ns = norm(screenRaw);
        if (na.isEmpty() || ns.isEmpty()) return 0;
        return score(na, tokens(na), ns, tokens(ns));
    }
}
