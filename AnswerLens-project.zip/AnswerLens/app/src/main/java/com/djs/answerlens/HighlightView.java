package com.djs.answerlens;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/** Full-screen, touch-through layer that draws boxes around answers. */
final class HighlightView extends View {
    static final class Mark {
        final Rect r;
        final int color;
        final String label;
        final boolean boxed;

        Mark(Rect r, int color, String label, boolean boxed) {
            this.r = r; this.color = color; this.label = label; this.boxed = boxed;
        }
    }

    private List<Mark> marks = new ArrayList<>();
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final int[] loc = new int[2];
    private final RectF tmp = new RectF();
    private final float dp;

    HighlightView(Context c) {
        super(c);
        dp = c.getResources().getDisplayMetrics().density;
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(3 * dp);
        fill.setStyle(Paint.Style.FILL);
        text.setColor(0xFFFFFFFF);
        text.setTextSize(12 * dp);
        text.setFakeBoldText(true);
    }

    void setMarks(List<Mark> m) {
        marks = m;
        invalidate();
    }

    void clear() {
        if (!marks.isEmpty()) setMarks(new ArrayList<Mark>());
    }

    @Override
    protected void onDraw(Canvas canvas) {
        getLocationOnScreen(loc);
        for (Mark m : marks) {
            float l = m.r.left - loc[0], t = m.r.top - loc[1], r = m.r.right - loc[0], b = m.r.bottom - loc[1];
            if (m.boxed) {
                tmp.set(l - 4 * dp, t - 3 * dp, r + 4 * dp, b + 3 * dp);
                fill.setColor((m.color & 0x00FFFFFF) | 0x33000000);
                canvas.drawRoundRect(tmp, 8 * dp, 8 * dp, fill);
                stroke.setColor(m.color);
                canvas.drawRoundRect(tmp, 8 * dp, 8 * dp, stroke);
            }
            if (m.label != null && !m.label.isEmpty()) {
                String s = m.label.length() > 70 ? m.label.substring(0, 69) + "…" : m.label;
                float w = text.measureText(s) + 12 * dp, h = 20 * dp;
                float x = Math.max(4 * dp, Math.min(l, getWidth() - w - 4 * dp));
                float y = m.boxed ? t - 3 * dp - h : b + 2 * dp;
                if (y < 0) y = b + 3 * dp;
                tmp.set(x, y, x + w, y + h);
                fill.setColor(m.color | 0xFF000000);
                canvas.drawRoundRect(tmp, 6 * dp, 6 * dp, fill);
                canvas.drawText(s, x + 6 * dp, y + h - 6 * dp, text);
            }
        }
    }
}
