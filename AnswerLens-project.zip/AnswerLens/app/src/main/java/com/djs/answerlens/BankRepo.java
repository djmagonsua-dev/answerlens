package com.djs.answerlens;

import android.content.Context;
import android.net.Uri;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Holds the user's answer bank and persists it in app-private storage. */
final class BankRepo {
    private BankRepo() {}
    static final Bank bank = new Bank();
    private static boolean loaded;

    static final String SAMPLE = "question,answer\n"
            + "What is the capital of the Philippines?,Manila\n"
            + "How many days are there in a week?,Seven\n"
            + "Republic Act No. 9165 is also known as?,Comprehensive Dangerous Drugs Act of 2002\n";

    private static File file(Context c) { return new File(c.getFilesDir(), "bank.txt"); }

    static void load(Context c) {
        if (loaded) return;
        loaded = true;
        File f = file(c);
        if (!f.exists()) return;
        try (InputStream in = new FileInputStream(f)) {
            fill(parse(readAll(in)));
        } catch (Exception ignored) { }
    }

    /** Parses and saves a bank. Returns the number of questions loaded, or 0 if nothing usable was found. */
    static int importText(Context c, String text) throws Exception {
        List<String[]> pairs = parse(text);
        if (pairs.isEmpty()) return 0;
        try (FileOutputStream out = new FileOutputStream(file(c))) {
            out.write(text.getBytes(StandardCharsets.UTF_8));
        }
        loaded = true;
        fill(pairs);
        return bank.size();
    }

    static int importUri(Context c, Uri uri) throws Exception {
        try (InputStream in = c.getContentResolver().openInputStream(uri)) {
            if (in == null) return 0;
            return importText(c, readAll(in));
        }
    }

    static void clear(Context c) {
        file(c).delete();
        bank.clear();
    }

    private static void fill(List<String[]> pairs) {
        bank.clear();
        for (String[] p : pairs) bank.add(p[0], p[1], false);
    }

    private static List<String[]> parse(String text) throws Exception {
        String t = text.trim();
        if (t.startsWith("﻿")) t = t.substring(1).trim();
        if (!t.startsWith("[")) return CsvParser.pairs(text);
        List<String[]> out = new ArrayList<>();
        JSONArray arr = new JSONArray(t);
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            String q = o.optString("question", "");
            String a = o.optString("answer", o.optString("correct", ""));
            if (!q.trim().isEmpty() && !a.trim().isEmpty()) out.add(new String[]{q, a});
        }
        return out;
    }

    static String readAll(InputStream in) throws Exception {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        return new String(bo.toByteArray(), StandardCharsets.UTF_8);
    }
}
