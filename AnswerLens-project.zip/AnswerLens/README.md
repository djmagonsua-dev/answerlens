# AnswerLens

Android reviewer overlay. It reads the text on your screen, matches questions against your own
answer bank, and shows the answer as floating text over the app you're in (nothing else opens).
It can also draw a box around the correct choice. For questions not in the bank, the blue
AI button asks an AI model (your own API key). It can also tap the answer for you.

## Get the APK (no computer needed)

1. Create a free GitHub account and a new **empty** repository.
2. Upload everything in this folder to it, including the hidden `.github` folder.
3. Open the repository's **Actions** tab. "Build APK" starts on its own and takes about 3 minutes.
4. When it turns green, open **Releases** and download `AnswerLens.apk`.

If the build goes red, copy the error text from the failed step and send it back for a fix.

## Install

1. Open the APK and allow installing from that source.
2. Open AnswerLens > **Open Accessibility settings** > AnswerLens > turn it on.
3. If the switch is greyed out: Settings > Apps > AnswerLens > menu (⋮) > **Allow restricted settings**.
4. Import your bank, or press **Load 3 sample questions** to try it.

## Answer bank format

CSV, first row is the header:

    question,answer
    What is the capital of the Philippines?,Manila

or JSON: `[{"question":"...","answer":"..."}]`

The answer should be the text of the correct choice. A single letter (A to E) also works when the
choices on screen are labelled "A.", "B." and so on. Small wording differences still match.

## On screen

- Works in any app that exposes real text (not pictures, games or video).
- Floating card (default): the question on screen and its answer. Green ✓ = your bank,
  orange "AI ➜" = AI answer (can be wrong). Drag to move; tap to switch answer-only / question + answer.
- Choose "Box around the correct choice" or "Both" in the app if you also want boxes.
- Bubble: ON/OFF pauses scanning, AI answers the questions on screen, drag to move.
- Select text in any app and choose "Ask AnswerLens" from the pop-up menu: the answer appears in the
  floating card (no window opens). Tap the card to dismiss it.

## AI and web search (optional)

In the app, choose Claude, Gemini or OpenAI-compatible, paste your own API key and save.
Claude and Gemini answers can use web search (on by default). "Answer new questions
automatically" sends question-like text without a button press; it is off by default because it
sends text from whatever app is open and uses API credit on every request.

## Scope

Built for reviewers and practice forms. It has no features for hiding from screen recording or
proctoring.
