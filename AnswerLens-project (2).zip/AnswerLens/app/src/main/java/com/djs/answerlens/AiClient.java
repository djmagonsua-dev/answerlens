package com.djs.answerlens;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/** Asks an AI model (optionally with web search) for answers. Call off the main thread. */
final class AiClient {
    private AiClient() {}

    private static final String SYS_SCREEN = "You are a study and review assistant. The user sends the text lines "
            + "currently visible on a phone screen, one per line, from any app. Find every line that is a question "
            + "or quiz item and work out its correct answer; use web search when you are not sure. Ignore menus, "
            + "buttons and chat. Reply with ONLY a JSON array and no other text. Each item: {\"question\": the "
            + "question text copied exactly from the input, \"answer\": the correct choice copied exactly from the "
            + "input, or a short answer of a few words if no choices are shown}. If there are no questions, "
            + "reply [].";

    private static final String SYS_ONE = "You are a study and review assistant. Answer the user's question or "
            + "explain the selected text. Use web search when it helps. Give the answer first in one short "
            + "sentence, then at most one short sentence of explanation. If choices are included, name the correct "
            + "choice. Plain text only.";

    private static final Pattern ARRAY_START = Pattern.compile("\\[\\s*\\{");

    /** Returns {question, answer} pairs for the questions found in the given screen lines. */
    static List<String[]> askScreen(String type, String url, String model, String key, boolean web,
                                    List<String> lines) throws Exception {
        StringBuilder sb = new StringBuilder();
        int n = 0;
        for (String l : lines) {
            if (n++ >= 150 || sb.length() > 7000) break;
            sb.append(l.replace('\n', ' ')).append('\n');
        }
        String text = call(type, url, model, key, web, SYS_SCREEN, sb.toString());
        List<String[]> out = new ArrayList<>();
        java.util.regex.Matcher m = ARRAY_START.matcher(text);
        int b = text.lastIndexOf(']');
        if (!m.find() || b < m.start()) {
            if (text.contains("[]")) return out;
            throw new Exception("AI gave no usable answer");
        }
        JSONArray arr = new JSONArray(text.substring(m.start(), b + 1));
        for (int i = 0; i < arr.length(); i++) {
            JSONObject it = arr.optJSONObject(i);
            if (it == null) continue;
            String q = it.optString("question", ""), ans = it.optString("answer", "");
            if (!q.trim().isEmpty() && !ans.trim().isEmpty()) out.add(new String[]{q, ans});
        }
        return out;
    }

    /** Returns a short plain-text answer for one question or selected passage. */
    static String askOne(String type, String url, String model, String key, boolean web, String question)
            throws Exception {
        String q = question.length() > 4000 ? question.substring(0, 4000) : question;
        String text = call(type, url, model, key, web, SYS_ONE, q).trim();
        if (text.isEmpty()) throw new Exception("AI gave no usable answer");
        return text;
    }

    private static String call(String type, String url, String model, String key, boolean web,
                               String system, String user) throws Exception {
        boolean anthropic = Cfg.TYPE_ANTHROPIC.equals(type), gemini = Cfg.TYPE_GEMINI.equals(type);
        JSONObject body = new JSONObject();
        body.put("model", model);
        if (gemini) {
            body.put("input", system + "\n\n" + user);
            if (web) body.put("tools", new JSONArray().put(new JSONObject().put("type", "google_search")));
        } else {
            JSONArray msgs = new JSONArray();
            if (anthropic) {
                body.put("max_tokens", 2000);
                body.put("system", system);
                if (web) {
                    body.put("tools", new JSONArray().put(new JSONObject()
                            .put("type", "web_search_20250305").put("name", "web_search").put("max_uses", 3)));
                }
            } else {
                msgs.put(new JSONObject().put("role", "system").put("content", system));
            }
            msgs.put(new JSONObject().put("role", "user").put("content", user));
            body.put("messages", msgs);
        }

        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        try {
            c.setRequestMethod("POST");
            c.setConnectTimeout(15000);
            c.setReadTimeout(120000);
            c.setDoOutput(true);
            c.setRequestProperty("content-type", "application/json");
            if (anthropic) {
                c.setRequestProperty("x-api-key", key);
                c.setRequestProperty("anthropic-version", "2023-06-01");
            } else if (gemini) {
                c.setRequestProperty("x-goog-api-key", key);
            } else {
                c.setRequestProperty("Authorization", "Bearer " + key);
            }
            try (OutputStream os = c.getOutputStream()) {
                os.write(body.toString().getBytes(StandardCharsets.UTF_8));
            }
            int code = c.getResponseCode();
            InputStream in = code < 400 ? c.getInputStream() : c.getErrorStream();
            String resp = in == null ? "" : BankRepo.readAll(in);
            if (code >= 400) {
                throw new Exception("AI error " + code + ": " + resp.substring(0, Math.min(160, resp.length())));
            }
            JSONObject o = new JSONObject(resp);
            StringBuilder text = new StringBuilder();
            if (anthropic) {
                appendText(o.optJSONArray("content"), text);
            } else if (gemini) {
                JSONArray steps = o.optJSONArray("steps");
                for (int i = 0; steps != null && i < steps.length(); i++) {
                    JSONObject st = steps.optJSONObject(i);
                    if (st != null && "model_output".equals(st.optString("type")))
                        appendText(st.optJSONArray("content"), text);
                }
            } else {
                text.append(o.getJSONArray("choices").getJSONObject(0).getJSONObject("message")
                        .optString("content", ""));
            }
            return text.toString();
        } finally {
            c.disconnect();
        }
    }

    private static void appendText(JSONArray parts, StringBuilder out) {
        for (int i = 0; parts != null && i < parts.length(); i++) {
            JSONObject p = parts.optJSONObject(i);
            if (p != null && "text".equals(p.optString("type"))) out.append(p.optString("text", ""));
        }
    }
}
