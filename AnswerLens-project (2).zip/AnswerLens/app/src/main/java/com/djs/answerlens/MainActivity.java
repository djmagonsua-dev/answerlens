package com.djs.answerlens;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQ_IMPORT = 7;
    private static final int ID_ANTHROPIC = 1001, ID_OPENAI = 1002, ID_GEMINI = 1003;
    private static final int ID_FLOAT = 2001, ID_BOX = 2002, ID_BOTH = 2003;

    private TextView status, bankInfo;
    private EditText url, model, key;
    private RadioGroup provider;
    private LinearLayout root;
    private int pad;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        final SharedPreferences p = Cfg.get(this);
        BankRepo.load(this);
        pad = (int) (16 * getResources().getDisplayMetrics().density);

        ScrollView sv = new ScrollView(this);
        sv.setFitsSystemWindows(true);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad * 2);
        sv.addView(root);
        setContentView(sv);

        head("AnswerLens", 24);
        text("Reviewer overlay: finds questions on your screen in any app and shows the answer, from your bank "
                + "or from an AI model with web search.");

        head("1. Turn on the service", 18);
        status = text("");
        button("Open Accessibility settings", new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
        });
        text("If the switch is greyed out: phone Settings > Apps > AnswerLens > menu (⋮) > Allow restricted "
                + "settings, then try again.");

        head("2. Answer bank", 18);
        bankInfo = text("");
        button("Import bank (CSV or JSON)", new View.OnClickListener() {
            @Override public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                startActivityForResult(i, REQ_IMPORT);
            }
        });
        button("Load 3 sample questions", new View.OnClickListener() {
            @Override public void onClick(View v) {
                try { BankRepo.importText(MainActivity.this, BankRepo.SAMPLE); } catch (Exception ignored) { }
                refresh();
            }
        });
        button("Clear bank", new View.OnClickListener() {
            @Override public void onClick(View v) { BankRepo.clear(MainActivity.this); refresh(); }
        });
        text("CSV: first row \"question,answer\", then one question per row. JSON: "
                + "[{\"question\":\"…\",\"answer\":\"…\"}]. The answer should be the text of the correct choice.");

        head("3. How to show the answer", 18);
        RadioGroup style = new RadioGroup(this);
        style.addView(radio(ID_FLOAT, "Floating text (default) — a small card you can drag anywhere"));
        style.addView(radio(ID_BOX, "Box around the correct choice"));
        style.addView(radio(ID_BOTH, "Both"));
        String st = p.getString(Cfg.STYLE, Cfg.STYLE_FLOAT);
        style.check(Cfg.STYLE_BOX.equals(st) ? ID_BOX : Cfg.STYLE_BOTH.equals(st) ? ID_BOTH : ID_FLOAT);
        style.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(RadioGroup g, int id) {
                p.edit().putString(Cfg.STYLE, id == ID_BOX ? Cfg.STYLE_BOX
                        : id == ID_BOTH ? Cfg.STYLE_BOTH : Cfg.STYLE_FLOAT).apply();
            }
        });
        root.addView(style);

        head("4. Auto-tap", 18);
        check("Tap the correct choice for me (bank answers)", p, Cfg.AUTO_TAP, false);
        check("Also tap AI answers (less reliable)", p, Cfg.AI_TAP, false);

        head("5. AI and web search", 18);
        text("For questions not in your bank, press the blue AI button on the floating bubble, or select text "
                + "in any app and choose \"Ask AnswerLens\" from the pop-up menu. The text is sent to the AI "
                + "service below using your own key.");
        check("Use web search for answers", p, Cfg.WEB, true);
        check("Answer new questions automatically (no button press)", p, Cfg.AUTO_AI, false);
        text("Careful with automatic mode: whenever scanning is ON, question-like text from whatever app is "
                + "open is sent to the AI service, and each request uses your API credit. Password fields are "
                + "never read.");
        provider = new RadioGroup(this);
        RadioButton ra = new RadioButton(this);
        ra.setId(ID_ANTHROPIC);
        ra.setText("Claude (Anthropic API)");
        RadioButton ro = new RadioButton(this);
        ro.setId(ID_OPENAI);
        ro.setText("OpenAI-compatible (no web search)");
        RadioButton rg = new RadioButton(this);
        rg.setId(ID_GEMINI);
        rg.setText("Gemini (Google API)");
        provider.addView(ra);
        provider.addView(rg);
        provider.addView(ro);
        root.addView(provider);
        url = field("API URL", false);
        model = field("Model name", false);
        key = field("API key", true);
        String savedType = p.getString(Cfg.AI_TYPE, Cfg.TYPE_ANTHROPIC);
        provider.check(Cfg.TYPE_GEMINI.equals(savedType) ? ID_GEMINI
                : Cfg.TYPE_OPENAI.equals(savedType) ? ID_OPENAI : ID_ANTHROPIC);
        url.setText(p.getString(Cfg.AI_URL, Cfg.URL_ANTHROPIC));
        model.setText(p.getString(Cfg.AI_MODEL, Cfg.MODEL_ANTHROPIC));
        key.setText(p.getString(Cfg.AI_KEY, ""));
        provider.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(RadioGroup g, int id) {
                if (id == ID_ANTHROPIC) {
                    url.setText(Cfg.URL_ANTHROPIC);
                    model.setText(Cfg.MODEL_ANTHROPIC);
                } else if (id == ID_GEMINI) {
                    url.setText(Cfg.URL_GEMINI);
                    model.setText(Cfg.MODEL_GEMINI);
                } else {
                    url.setText(Cfg.URL_OPENAI);
                    model.setText("");
                }
            }
        });
        button("Save AI settings", new View.OnClickListener() {
            @Override public void onClick(View v) {
                p.edit()
                        .putString(Cfg.AI_TYPE, provider.getCheckedRadioButtonId() == ID_GEMINI
                                ? Cfg.TYPE_GEMINI : provider.getCheckedRadioButtonId() == ID_OPENAI
                                ? Cfg.TYPE_OPENAI : Cfg.TYPE_ANTHROPIC)
                        .putString(Cfg.AI_URL, url.getText().toString().trim())
                        .putString(Cfg.AI_MODEL, model.getText().toString().trim())
                        .putString(Cfg.AI_KEY, key.getText().toString().trim())
                        .apply();
                Toast.makeText(MainActivity.this, "Saved", Toast.LENGTH_SHORT).show();
            }
        });

        head("How to use", 18);
        text("Works in any app that shows real text (not pictures or games). The floating card shows the "
                + "question on screen and its answer: green ✓ = from your bank, orange AI ➜ = AI answer (can be "
                + "wrong). Drag the card to move it; tap it to switch between answer-only and question + answer. "
                + "Press the blue AI button for questions not in your bank. Tap ON/OFF on the bubble to pause.");
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        boolean on = LensService.instance != null;
        status.setText(on ? "Service is ON ✓" : "Service is OFF — turn on AnswerLens in Accessibility settings.");
        status.setTextColor(on ? 0xFF1E9E4A : 0xFFC62828);
        bankInfo.setText("Questions loaded: " + BankRepo.bank.size());
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_IMPORT || res != RESULT_OK || data == null || data.getData() == null) return;
        String msg;
        try {
            int n = BankRepo.importUri(this, data.getData());
            msg = n > 0 ? "Loaded " + n + " questions" : "No questions found. Check the file format.";
        } catch (Exception ex) {
            msg = "Could not read file: " + ex.getMessage();
        }
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
        refresh();
    }

    // ---------- small UI helpers ----------

    private TextView head(String s, int sp) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(0xFF111111);
        t.setPadding(0, pad, 0, pad / 4);
        root.addView(t);
        return t;
    }

    private TextView text(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(14);
        t.setPadding(0, pad / 4, 0, pad / 4);
        root.addView(t);
        return t;
    }

    private RadioButton radio(int id, String s) {
        RadioButton r = new RadioButton(this);
        r.setId(id);
        r.setText(s);
        return r;
    }

    private void button(String s, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        root.addView(b);
    }

    private void check(String s, final SharedPreferences p, final String prefKey, boolean def) {
        CheckBox c = new CheckBox(this);
        c.setText(s);
        c.setChecked(p.getBoolean(prefKey, def));
        c.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton v, boolean on) {
                p.edit().putBoolean(prefKey, on).apply();
            }
        });
        root.addView(c);
    }

    private EditText field(String hint, boolean secret) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setTextSize(14);
        e.setInputType(InputType.TYPE_CLASS_TEXT | (secret ? InputType.TYPE_TEXT_VARIATION_PASSWORD
                : InputType.TYPE_TEXT_VARIATION_URI));
        root.addView(e);
        return e;
    }
}
