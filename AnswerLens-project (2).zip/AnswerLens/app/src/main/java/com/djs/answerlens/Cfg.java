package com.djs.answerlens;

import android.content.Context;
import android.content.SharedPreferences;

final class Cfg {
    private Cfg() {}
    static final String AUTO_TAP = "autoTap", AI_TAP = "aiTap", WEB = "web", AUTO_AI = "autoAi";
    static final String STYLE = "style", STYLE_FLOAT = "float", STYLE_BOX = "box", STYLE_BOTH = "both";
    static final String AI_TYPE = "aiType", AI_URL = "aiUrl", AI_MODEL = "aiModel", AI_KEY = "aiKey";
    static final String TYPE_ANTHROPIC = "anthropic", TYPE_GEMINI = "gemini", TYPE_OPENAI = "openai";
    static final String URL_ANTHROPIC = "https://api.anthropic.com/v1/messages";
    static final String MODEL_ANTHROPIC = "claude-haiku-5-5";
    static final String URL_GEMINI = "https://generativelanguage.googleapis.com/v1beta/interactions";
    static final String MODEL_GEMINI = "gemini-3.8-flash";
    static final String URL_OPENAI = "https://api.openai.com/v1/chat/completions";

    static SharedPreferences get(Context c) {
        return c.getSharedPreferences("cfg", Context.MODE_PRIVATE);
    }
}
